#### Description

Have you heard of Rust? Fix the syntax errors in this Rust file to print the flag!Download the Rust code [here](https://challenge-files.picoctf.net/c_verbal_sleep/dcdaf491b35c1d0f5075e9583edbbb7aaea1dffb6ad32bc000e4d87b5200ff7b/fixme3.tar.gz).
¿Has oído hablar de Rust? ¡Corrige los errores de sintaxis en este archivo de Rust para imprimir la bandera!Descargue el código de Rust [aquí](https://challenge-files.picoctf.net/c_verbal_sleep/dcdaf491b35c1d0f5075e9583edbbb7aaea1dffb6ad32bc000e4d87b5200ff7b/fixme3.tar.gz) .

* Consejos:
	- Leer los comentarios.
![[Pasted image 20250414202644.png]]
* se descomenta la función:
  ![[Pasted image 20250414202845.png]]
* ![[Pasted image 20250414202934.png]]
* 
## Solución:

```
picoCTF{n0w_y0uv3_f1x3d_1h3m_411}
```